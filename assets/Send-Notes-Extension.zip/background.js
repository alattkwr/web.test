const STORAGE_KEY = "highlightNotesState";
const CONTEXT_MENU_ID = "save-highlight-to-notes";
const DEFAULT_SETTINGS = {
  apiKey: "",
  model: "gpt-5-mini",
  notesStyle: "study"
};
const MAX_ARTICLE_LENGTH = 25000;

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.create({
    id: CONTEXT_MENU_ID,
    title: "Save Highlight to Notes",
    contexts: ["selection"]
  });

  const existing = await chrome.storage.local.get(STORAGE_KEY);
  if (!existing[STORAGE_KEY]) {
    await chrome.storage.local.set({
      [STORAGE_KEY]: {
        highlights: [],
        notes: [],
        sources: {},
        settings: { ...DEFAULT_SETTINGS },
        lastUpdated: null
      }
    });
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID || !tab?.id) {
    return;
  }

  await captureHighlightFromTab(tab.id, info.selectionText || "");
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "capture-highlight") {
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const sourceMeta = getSourceMetaFromTabUrl(tab?.url || "");
  if (!tab?.id || !sourceMeta.isSupportedSource) {
    return;
  }

  await captureHighlightFromTab(tab.id, "");
});

async function captureHighlightFromTab(tabId, fallbackSelectionText = "") {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const sourceMeta = getSourceMetaFromTabUrl(tab?.url || "");
  if (!tab?.id || !sourceMeta.isSupportedSource) {
    return;
  }

  const payload = await getSelectionPayload(tab.id);
  const selectedText = (payload?.selectedText || fallbackSelectionText || "").trim();
  if (!selectedText) {
    return;
  }

  const current = await chrome.storage.local.get(STORAGE_KEY);
  const state = normalizeState(current[STORAGE_KEY]);
  const url = sourceMeta.sourceUrl || payload?.url || tab.url;

  state.highlights.unshift({
    id: crypto.randomUUID(),
    text: selectedText,
    pageTitle: payload?.pageTitle || tab.title || "Untitled page",
    url,
    capturedAt: new Date().toISOString()
  });

  if (url) {
    state.sources[url] = buildSourceRecord({
      pageTitle: payload?.pageTitle || tab.title || "Untitled page",
      url,
      articleText: payload?.articleText || "",
      isPdf: sourceMeta.isPdf
    });
  }

  state.lastUpdated = new Date().toISOString();
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function getSelectionPayload(tabId) {
  const payload = await chrome.tabs.sendMessage(tabId, { type: "GET_SELECTION" }).catch(() => null);
  if (payload?.selectedText) {
    return payload;
  }

  const injected = await chrome.scripting
    .executeScript({
      target: { tabId },
      func: () => {
        const normalizeWhitespace = (value) => value.replace(/\s+/g, " ").trim();
        const getArticleText = () => {
          const candidates = [
            document.querySelector("article"),
            document.querySelector("main"),
            document.body
          ].filter(Boolean);

          for (const candidate of candidates) {
            const text = normalizeWhitespace(candidate.innerText || "");
            if (text.length > 800) {
              return text;
            }
          }

          return normalizeWhitespace(document.body?.innerText || "");
        };

        return {
          selectedText: window.getSelection()?.toString().trim() || "",
          pageTitle: document.title || "Untitled page",
          url: window.location.href,
          articleText: getArticleText()
        };
      }
    })
    .catch(() => []);

  return injected[0]?.result || null;
}

function buildSourceRecord({ pageTitle, url, articleText, isPdf }) {
  return {
    pageTitle,
    url,
    articleText: isPdf ? "" : articleText.slice(0, MAX_ARTICLE_LENGTH),
    sourceType: isPdf ? "pdf" : "html",
    capturedAt: new Date().toISOString()
  };
}

function getSourceMetaFromTabUrl(tabUrl) {
  if (!tabUrl) {
    return { isSupportedSource: false, isPdf: false, sourceUrl: "" };
  }

  const viewerMatch = extractPdfUrlFromViewer(tabUrl);
  if (viewerMatch) {
    return {
      isSupportedSource: true,
      isPdf: true,
      sourceUrl: viewerMatch
    };
  }

  if (/^https?:/i.test(tabUrl)) {
    return {
      isSupportedSource: true,
      isPdf: /\.pdf(?:$|[?#])/i.test(tabUrl),
      sourceUrl: tabUrl
    };
  }

  return { isSupportedSource: false, isPdf: false, sourceUrl: "" };
}

function extractPdfUrlFromViewer(tabUrl) {
  try {
    const parsed = new URL(tabUrl);
    const src = parsed.searchParams.get("src");
    if (src && /^https?:/i.test(src)) {
      return src;
    }
  } catch {
    return "";
  }
  return "";
}

function normalizeState(state) {
  return {
    highlights: Array.isArray(state?.highlights) ? state.highlights : [],
    notes: Array.isArray(state?.notes) ? state.notes : [],
    sources: state?.sources && typeof state.sources === "object" ? state.sources : {},
    settings: {
      ...DEFAULT_SETTINGS,
      ...(state?.settings || {})
    },
    lastUpdated: state?.lastUpdated || null
  };
}
