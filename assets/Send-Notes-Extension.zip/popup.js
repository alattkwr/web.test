const STORAGE_KEY = "highlightNotesState";
const DEFAULT_SETTINGS = {
  apiKey: "",
  model: "gpt-5-mini",
  notesStyle: "study",
  additionalContext: ""
};
const MAX_PROMPT_SOURCE_LENGTH = 12000;
const MAX_PROMPT_SOURCES = 3;
const MAX_PDF_BYTES = 20 * 1024 * 1024;

const elements = {
  captureSelectionButton: document.getElementById("captureSelectionButton"),
  generateNotesButton: document.getElementById("generateNotesButton"),
  importPdfButton: document.getElementById("importPdfButton"),
  copyPromptButton: document.getElementById("copyPromptButton"),
  clearAllButton: document.getElementById("clearAllButton"),
  exportButton: document.getElementById("exportButton"),
  saveSettingsButton: document.getElementById("saveSettingsButton"),
  apiKeyInput: document.getElementById("apiKeyInput"),
  modelSelect: document.getElementById("modelSelect"),
  notesStyleSelect: document.getElementById("notesStyleSelect"),
  additionalContextInput: document.getElementById("additionalContextInput"),
  pdfFileInput: document.getElementById("pdfFileInput"),
  notesList: document.getElementById("notesList"),
  highlightList: document.getElementById("highlightList"),
  highlightCount: document.getElementById("highlightCount"),
  sourceList: document.getElementById("sourceList"),
  sourceCount: document.getElementById("sourceCount"),
  statusMessage: document.getElementById("statusMessage")
};

document.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  await render();
});

function bindEvents() {
  elements.captureSelectionButton.addEventListener("click", captureSelectionFromActiveTab);
  elements.generateNotesButton.addEventListener("click", generateNotes);
  elements.importPdfButton.addEventListener("click", () => elements.pdfFileInput.click());
  elements.copyPromptButton.addEventListener("click", copyPrompt);
  elements.clearAllButton.addEventListener("click", clearAll);
  elements.exportButton.addEventListener("click", exportForWord);
  elements.saveSettingsButton.addEventListener("click", saveSettings);
  elements.pdfFileInput.addEventListener("change", importPdfFile);
}

async function getState() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  const rawState = result[STORAGE_KEY] || {
    highlights: [],
    notes: [],
    sources: {},
    settings: { ...DEFAULT_SETTINGS },
    lastUpdated: null
  };
  return normalizeState(rawState);
}

async function setState(state) {
  state.lastUpdated = new Date().toISOString();
  await chrome.storage.local.set({ [STORAGE_KEY]: state });
}

async function render() {
  const state = await getState();
  populateSettings(state.settings || DEFAULT_SETTINGS);
  renderSources(state.sources);
  renderHighlights(state.highlights);
  renderNotes(state.notes);
}

function populateSettings(settings) {
  elements.apiKeyInput.value = settings.apiKey || "";
  elements.modelSelect.value = settings.model || DEFAULT_SETTINGS.model;
  elements.notesStyleSelect.value = settings.notesStyle || DEFAULT_SETTINGS.notesStyle;
  elements.additionalContextInput.value = settings.additionalContext || "";
}

function renderHighlights(highlights) {
  elements.highlightCount.textContent = String(highlights.length);

  if (!highlights.length) {
    elements.highlightList.className = "stack emptyState";
    elements.highlightList.textContent = "No highlights captured yet.";
    return;
  }

  elements.highlightList.className = "stack";
  elements.highlightList.innerHTML = highlights
    .map(
      (highlight) => `
        <article class="card">
          <div>${escapeHtml(highlight.text)}</div>
          <div class="meta">
            <div>${escapeHtml(highlight.pageTitle || "Untitled page")}</div>
            <div>${escapeHtml(formatUrl(highlight.url))}</div>
          </div>
        </article>
      `
    )
    .join("");
}

function renderSources(sources) {
  const sourceEntries = Object.values(sources || {}).sort((left, right) =>
    (right.capturedAt || "").localeCompare(left.capturedAt || "")
  );
  elements.sourceCount.textContent = String(sourceEntries.length);

  if (!sourceEntries.length) {
    elements.sourceList.className = "stack emptyState";
    elements.sourceList.textContent = "No imported sources yet.";
    return;
  }

  elements.sourceList.className = "stack";
  elements.sourceList.innerHTML = sourceEntries
    .map(
      (source) => `
        <article class="card">
          <div>${escapeHtml(source.pageTitle || source.fileName || "Untitled source")}</div>
          <div class="meta">
            <div>${escapeHtml(source.sourceType === "pdf-upload" ? "Imported PDF" : source.sourceType === "pdf" ? "PDF source" : "Web article")}</div>
            <div>${escapeHtml(source.sourceType === "pdf-upload" ? source.fileName || "Local file" : formatUrl(source.url || ""))}</div>
          </div>
        </article>
      `
    )
    .join("");
}

function renderNotes(notes) {
  if (!notes.length) {
    elements.notesList.className = "stack emptyState";
    elements.notesList.textContent = "No notes yet.";
    return;
  }

  elements.notesList.className = "stack";
  elements.notesList.innerHTML = notes
    .map(
      (note, index) => `
        <article class="card">
          <div class="noteBody">${formatNoteContent(note.content)}</div>
          <div class="meta">
            <div>${escapeHtml(formatNoteLabel(note, notes.length - index))}</div>
            <div>${new Date(note.createdAt).toLocaleString()}</div>
          </div>
        </article>
      `
    )
    .join("");
}

async function captureSelectionFromActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus("No active tab available.");
    return;
  }

  const sourceMeta = getSourceMetaFromTabUrl(tab.url || "");
  if (!sourceMeta.isSupportedSource) {
    setStatus("Open a regular webpage before capturing a highlight, or import a PDF.");
    return;
  }

  if (sourceMeta.isPdf) {
    setStatus("For PDFs, highlight text and use the right-click menu to capture it.");
    return;
  }

  const response = await chrome.tabs.sendMessage(tab.id, { type: "GET_SELECTION" }).catch(() => null);
  const selectedText = response?.selectedText?.trim();

  if (!selectedText) {
    setStatus("Highlight some text on the page first.");
    return;
  }

  const state = await getState();
  state.highlights.unshift({
    id: crypto.randomUUID(),
    text: selectedText,
    pageTitle: response.pageTitle || tab.title || "Untitled page",
    url: response.url || tab.url,
    capturedAt: new Date().toISOString()
  });

  if (response.url || tab.url) {
    const url = response.url || tab.url;
    state.sources[url] = {
      pageTitle: response.pageTitle || tab.title || "Untitled page",
      url,
      articleText: truncateText(response.articleText || "", 25000),
      capturedAt: new Date().toISOString()
    };
  }

  await setState(state);
  await render();
  setStatus("Highlight captured.");
}

async function copyPrompt() {
  const state = await getState();
  if (!state.highlights.length) {
    setStatus("Capture at least one highlight before copying a prompt.");
    return;
  }

  if (hasPdfSources(state)) {
    setStatus("Copy prompt is unavailable when PDF sources are included.");
    return;
  }

  const prompt = buildPrompt(state, state.settings || DEFAULT_SETTINGS);
  await navigator.clipboard.writeText(prompt);
  setStatus("AI prompt copied to clipboard.");
}

async function saveSettings() {
  const state = await getState();
  state.settings = readSettingsFromForm();
  await setState(state);
  setStatus("AI settings saved.");
}

async function generateNotes() {
  const state = await getState();
  state.settings = readSettingsFromForm();

  if (!state.highlights.length && !Object.keys(state.sources).length) {
    setStatus("Capture a highlight or import a PDF before generating notes.");
    return;
  }

  if (!state.settings.apiKey.trim()) {
    setStatus("Add an OpenAI API key first.");
    return;
  }

  await setState(state);
  setStatus("Generating notes...");
  setBusy(true);

  try {
    const requestInput = await buildModelInput(state, state.settings);
    const content = await callOpenAI(requestInput, state.settings);

    state.notes.unshift({
      id: crypto.randomUUID(),
      content,
      createdAt: new Date().toISOString(),
      source: "openai",
      model: state.settings.model
    });

    await setState(state);
    await render();
    setStatus("AI note generated.");
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to generate notes.";
    setStatus(message);
  } finally {
    setBusy(false);
  }
}

async function clearAll() {
  const state = await getState();
  await setState({
    highlights: [],
    notes: [],
    sources: {},
    settings: state.settings,
    lastUpdated: null
  });
  await render();
  setStatus("All highlights and notes cleared.");
}

async function importPdfFile(event) {
  const [file] = Array.from(event.target.files || []);
  if (!file) {
    return;
  }

  if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
    setStatus("Choose a PDF file.");
    event.target.value = "";
    return;
  }

  if (file.size > MAX_PDF_BYTES) {
    setStatus("PDF is too large for this prototype. Try a file under 20 MB.");
    event.target.value = "";
    return;
  }

  try {
    const fileData = await readFileAsDataUrl(file);
    const state = await getState();
    const sourceId = `upload:${crypto.randomUUID()}`;
    state.sources[sourceId] = {
      pageTitle: file.name.replace(/\.pdf$/i, ""),
      fileName: file.name,
      url: sourceId,
      fileData,
      sourceType: "pdf-upload",
      capturedAt: new Date().toISOString()
    };
    await setState(state);
    await render();
    setStatus("PDF imported.");
  } catch {
    setStatus("Unable to import PDF.");
  } finally {
    event.target.value = "";
  }
}

async function exportForWord() {
  const state = await getState();
  if (!state.notes.length && !state.highlights.length) {
    setStatus("There is nothing to export yet.");
    return;
  }

  const html = buildWordDocument(state);
  const blob = new Blob([html], { type: "application/msword" });
  const url = URL.createObjectURL(blob);

  await chrome.downloads.download({
    url,
    filename: `highlight-notes-${formatDateForFile(new Date())}.doc`,
    saveAs: true
  });

  setTimeout(() => URL.revokeObjectURL(url), 15000);
  setStatus("Export started.");
}

function buildPrompt(state, settings = DEFAULT_SETTINGS) {
  const relevantSources = collectRelevantSources(state.highlights, state.sources);
  const sourceSection = relevantSources.length
    ? relevantSources
        .map((source, index) => {
          return [
            `Source article ${index + 1}: ${source.pageTitle}`,
            `URL: ${source.url}`,
            truncateText(source.articleText, MAX_PROMPT_SOURCE_LENGTH)
          ].join("\n");
        })
        .join("\n\n")
    : "No article body was captured for these highlights.";

  const highlightSection = buildHighlightSection(state.highlights);

  const existingNotes = state.notes.length
    ? state.notes
        .slice(0, 3)
        .reverse()
        .map((note, index) => `Existing note ${index + 1}:\n${note.content}`)
        .join("\n\n")
    : "No existing notes yet.";

  const additionalContextSection = buildAdditionalContextSection(settings.additionalContext);

  return [
    `First read the source article text below, then write coherent ${settings.notesStyle} notes focused on the highlighted excerpts.`,
    "Requirements:",
    "- Use the full source article text to preserve context, chronology, and nuance.",
    "- Focus the notes on the highlighted excerpts, but correct or expand them when the surrounding article meaning requires it.",
    "- Keep the writing concise and well structured.",
    "- Use clear section headers in markdown with bold titles.",
    "- Use indented bullet points for supporting details and examples.",
    "- Merge overlapping points and avoid repetition.",
    "- Preserve important facts, names, and claims from the excerpts.",
    "- Do not invent details that are not present in the excerpts.",
    "- End with a short bullet list of key takeaways.",
    additionalContextSection,
    "",
    existingNotes,
    "",
    sourceSection,
    "",
    highlightSection
  ].join("\n");
}

async function buildModelInput(state, settings) {
  const relevantSources = collectRelevantSources(state.highlights, state.sources);
  const pdfSources = relevantSources.filter((source) => source.sourceType === "pdf");
  const uploadedPdfSources = relevantSources.filter((source) => source.sourceType === "pdf-upload");

  if (!pdfSources.length && !uploadedPdfSources.length) {
    return buildPrompt(state, settings);
  }

  const content = [
    {
      type: "input_text",
      text: buildPdfAwarePrompt(state, settings)
    }
  ];

  for (const source of [...pdfSources, ...uploadedPdfSources]) {
    const fileData = source.fileData || (await fetchPdfAsBase64(source.url));
    content.push({
      type: "input_file",
      filename: source.fileName || buildPdfFileName(source.url),
      file_data: fileData
    });
  }

  const htmlSources = relevantSources.filter(
    (source) => source.sourceType !== "pdf" && source.sourceType !== "pdf-upload"
  );
  if (htmlSources.length) {
    content.push({
      type: "input_text",
      text: buildHtmlSourceAppendix(htmlSources)
    });
  }

  return [
    {
      role: "user",
      content
    }
  ];
}

function buildPdfAwarePrompt(state, settings) {
  const existingNotes = state.notes.length
    ? state.notes
        .slice(0, 3)
        .reverse()
        .map((note, index) => `Existing note ${index + 1}:\n${note.content}`)
        .join("\n\n")
    : "No existing notes yet.";

  const highlightSection = buildHighlightSection(state.highlights);
  const focusInstruction = highlightSection
    ? "Focus the notes on the highlighted excerpts first, using the full source for context."
    : "No highlights were captured. Produce a structured note set for the full source, emphasizing the most important claims, sections, and takeaways.";
  const additionalContextSection = buildAdditionalContextSection(settings.additionalContext);

  return [
    `Read the attached PDF source files and any included article text, then write coherent ${settings.notesStyle} notes focused on the highlighted excerpts.`,
    "Requirements:",
    "- Use the PDF or article context to preserve chronology, definitions, and nuance.",
    `- ${focusInstruction}`,
    "- Keep the writing concise and well structured.",
    "- Use clear section headers in markdown with bold titles.",
    "- Use indented bullet points for supporting details and examples.",
    "- Merge overlapping points and avoid repetition.",
    "- Preserve important facts, names, and claims from the excerpts.",
    "- Do not invent details that are not present in the sources.",
    "- End with a short bullet list of key takeaways.",
    additionalContextSection,
    "",
    existingNotes,
    "",
    highlightSection || "No captured excerpts."
  ].join("\n");
}

function buildHtmlSourceAppendix(sources) {
  return [
    "Additional webpage source context:",
    "",
    sources
      .map((source, index) => {
        return [
          `Source article ${index + 1}: ${source.pageTitle}`,
          `URL: ${source.url}`,
          truncateText(source.articleText || "", MAX_PROMPT_SOURCE_LENGTH)
        ].join("\n");
      })
      .join("\n\n")
  ].join("\n");
}

function buildWordDocument(state) {
  const noteItems = state.notes.length
    ? state.notes
        .slice()
        .reverse()
        .map(
          (note) => `
            <section>
              <h2>AI Note</h2>
              <p>${escapeHtml(note.content).replace(/\n/g, "<br>")}</p>
              <p><small>${escapeHtml(new Date(note.createdAt).toLocaleString())}</small></p>
            </section>
          `
        )
        .join("")
    : "<p>No AI notes were imported.</p>";

  const highlightItems = state.highlights.length
    ? state.highlights
        .slice()
        .reverse()
        .map(
          (highlight) => `
            <section>
              <h2>Captured Highlight</h2>
              <p>${escapeHtml(highlight.text)}</p>
              <p><small>${escapeHtml(highlight.pageTitle)}<br>${escapeHtml(highlight.url)}</small></p>
            </section>
          `
        )
        .join("")
    : "<p>No highlights were captured.</p>";

  return `
    <html xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:w="urn:schemas-microsoft-com:office:word"
          xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8">
        <title>Highlight Notes Export</title>
        <style>
          body { font-family: Georgia, serif; margin: 32px; color: #2d2218; }
          h1 { color: #8c3f1e; }
          h2 { margin-top: 28px; color: #c65d2e; }
          p { line-height: 1.5; }
          small { color: #6f5b49; }
        </style>
      </head>
      <body>
        <h1>Highlight Notes Export</h1>
        <p>Generated ${escapeHtml(new Date().toLocaleString())}</p>
        ${noteItems}
        ${highlightItems}
      </body>
    </html>
  `;
}

function setStatus(message) {
  elements.statusMessage.textContent = message;
}

function normalizeState(state) {
  return {
    highlights: Array.isArray(state.highlights) ? state.highlights : [],
    notes: Array.isArray(state.notes) ? state.notes : [],
    sources: state.sources && typeof state.sources === "object" ? state.sources : {},
    settings: {
      ...DEFAULT_SETTINGS,
      ...(state.settings || {})
    },
    lastUpdated: state.lastUpdated || null
  };
}

function setBusy(isBusy) {
  elements.generateNotesButton.disabled = isBusy;
  elements.captureSelectionButton.disabled = isBusy;
  elements.importPdfButton.disabled = isBusy;
  elements.saveSettingsButton.disabled = isBusy;
}

function readSettingsFromForm() {
  return {
    apiKey: elements.apiKeyInput.value.trim(),
    model: elements.modelSelect.value,
    notesStyle: elements.notesStyleSelect.value,
    additionalContext: elements.additionalContextInput.value.trim()
  };
}

async function callOpenAI(prompt, settings) {
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${settings.apiKey}`
    },
    body: JSON.stringify({
      model: settings.model,
      reasoning: {
        effort: "low"
      },
      input: prompt
    })
  });

  if (!response.ok) {
    let message = `OpenAI request failed (${response.status}).`;
    try {
      const errorPayload = await response.json();
      const apiMessage = errorPayload?.error?.message;
      if (apiMessage) {
        message = apiMessage;
      }
    } catch {
      // Ignore JSON parsing failures and keep the generic message.
    }
    throw new Error(message);
  }

  const data = await response.json();
  if (data?.status === "failed" && data?.error?.message) {
    throw new Error(data.error.message);
  }

  if (data?.status === "incomplete" && data?.incomplete_details?.reason) {
    throw new Error(`OpenAI returned an incomplete response: ${data.incomplete_details.reason}.`);
  }

  const outputText = extractResponseText(data).trim();

  if (!outputText) {
    throw new Error("OpenAI returned an empty response.");
  }

  return outputText;
}

function extractResponseText(data) {
  if (typeof data?.output_text === "string" && data.output_text.trim()) {
    return data.output_text;
  }

  if (!Array.isArray(data?.output)) {
    return "";
  }

  return data.output
    .filter((item) => item?.type === "message" && Array.isArray(item.content))
    .flatMap((item) => item.content)
    .filter((content) => content?.type === "output_text" && typeof content.text === "string")
    .map((content) => content.text)
    .join("\n")
    .trim();
}

function formatNoteLabel(note, fallbackNumber) {
  if (note.source === "openai" && note.model) {
    return `AI note via ${note.model}`;
  }
  return `Note ${fallbackNumber}`;
}

function formatNoteContent(value) {
  const escaped = escapeHtml(value || "");
  const lines = escaped.split("\n");
  let html = "";
  let inList = false;

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    const trimmed = line.trim();

    if (!trimmed) {
      if (inList) {
        html += "</ul>";
        inList = false;
      }
      continue;
    }

    const headingMatch = trimmed.match(/^\*\*(.+?)\*\*:?$/);
    if (headingMatch) {
      if (inList) {
        html += "</ul>";
        inList = false;
      }
      html += `<h3>${headingMatch[1]}</h3>`;
      continue;
    }

    const listMatch = trimmed.match(/^[-*•]\s+(.+)$/);
    if (listMatch) {
      if (!inList) {
        html += "<ul>";
        inList = true;
      }
      html += `<li>${listMatch[1]}</li>`;
      continue;
    }

    if (inList) {
      html += "</ul>";
      inList = false;
    }

    html += `<p>${applyInlineFormatting(trimmed)}</p>`;
  }

  if (inList) {
    html += "</ul>";
  }

  return html || "<p>No note content yet.</p>";
}

function applyInlineFormatting(value) {
  return value.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
}

function collectRelevantSources(highlights, sources) {
  const seen = new Set();
  const relevant = [];

  for (const highlight of highlights) {
    if (!highlight?.url || seen.has(highlight.url)) {
      continue;
    }
    seen.add(highlight.url);
    const source = sources[highlight.url];
    if (source && (source.articleText || source.sourceType === "pdf" || source.sourceType === "pdf-upload")) {
      relevant.push(source);
    }
    if (relevant.length >= MAX_PROMPT_SOURCES) {
      break;
    }
  }

  if (!relevant.length) {
    const recentSources = Object.values(sources || {})
      .sort((left, right) => (right.capturedAt || "").localeCompare(left.capturedAt || ""))
      .slice(0, MAX_PROMPT_SOURCES);
    relevant.push(...recentSources);
  }

  return relevant;
}

function hasPdfSources(state) {
  return collectRelevantSources(state.highlights, state.sources).some(
    (source) => source.sourceType === "pdf" || source.sourceType === "pdf-upload"
  );
}

async function fetchPdfAsBase64(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Unable to fetch PDF source (${response.status}).`);
  }

  const buffer = await response.arrayBuffer();
  if (buffer.byteLength > MAX_PDF_BYTES) {
    throw new Error("PDF is too large for this prototype. Try a file under 20 MB.");
  }

  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }

  return `data:application/pdf;base64,${btoa(binary)}`;
}

function buildPdfFileName(url) {
  try {
    const parsed = new URL(url);
    const lastSegment = parsed.pathname.split("/").filter(Boolean).pop();
    return lastSegment || "document.pdf";
  } catch {
    return "document.pdf";
  }
}

function buildHighlightSection(highlights) {
  return highlights
    .slice(0, 8)
    .reverse()
    .map((highlight, index) => {
      return [
        `Excerpt ${index + 1}:`,
        highlight.text,
        `Source: ${highlight.pageTitle} (${highlight.url})`
      ].join("\n");
    })
    .join("\n\n");
}

function buildAdditionalContextSection(value) {
  if (!value?.trim()) {
    return "";
  }
  return `- Follow these additional user instructions: ${value.trim()}`;
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function escapeHtml(value) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function formatUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname;
  } catch {
    return url || "";
  }
}

function formatDateForFile(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  return `${year}-${month}-${day}-${hours}${minutes}`;
}

function truncateText(value, maxLength) {
  if (!value || value.length <= maxLength) {
    return value;
  }
  return `${value.slice(0, maxLength)}...`;
}

function getSourceMetaFromTabUrl(tabUrl) {
  if (!tabUrl) {
    return { isSupportedSource: false, isPdf: false, sourceUrl: "" };
  }

  const viewerMatch = extractPdfUrlFromViewer(tabUrl);
  if (viewerMatch) {
    return {
      isSupportedSource: true,
      isPdf: true,
      sourceUrl: viewerMatch
    };
  }

  if (/^https?:/i.test(tabUrl)) {
    return {
      isSupportedSource: true,
      isPdf: /\.pdf(?:$|[?#])/i.test(tabUrl),
      sourceUrl: tabUrl
    };
  }

  return { isSupportedSource: false, isPdf: false, sourceUrl: "" };
}

function extractPdfUrlFromViewer(tabUrl) {
  try {
    const parsed = new URL(tabUrl);
    const src = parsed.searchParams.get("src");
    if (src && /^https?:/i.test(src)) {
      return src;
    }
  } catch {
    return "";
  }
  return "";
}
