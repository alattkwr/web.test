chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "GET_SELECTION") {
    return false;
  }

  const selectedText = window.getSelection()?.toString().trim() || "";
  sendResponse({
    selectedText,
    pageTitle: document.title || "Untitled page",
    url: window.location.href,
    articleText: getArticleText()
  });
  return true;
});

function getArticleText() {
  const candidates = [
    document.querySelector("article"),
    document.querySelector("main"),
    document.body
  ].filter(Boolean);

  for (const candidate of candidates) {
    const text = normalizeWhitespace(candidate.innerText || "");
    if (text.length > 800) {
      return text;
    }
  }

  return normalizeWhitespace(document.body?.innerText || "");
}

function normalizeWhitespace(value) {
  return value.replace(/\s+/g, " ").trim();
}
