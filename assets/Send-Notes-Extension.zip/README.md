# Send Notes

Send Notes is a Chrome extension for turning highlights into notes. It lets you save key passages from articles, PDFs, and docs, then turn them into clear study notes, summaries, or research outlines with AI.

The main idea is simple: you still do the reading first. Instead of pasting entire pages into an LLM, you highlight what matters and use those selections as the basis for better-organized notes.

## Install and Run

1. Extract the zip file.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the Send Notes Extension folder.
6. Pin the extension if you want quick access from the Chrome toolbar.

## How to Use

1. Open a webpage or prepare a PDF you want to work with.
2. Highlight a sentence or paragraph you want to save.
3. Save the highlight by either:
   right-clicking and choosing **Save Highlight to Notes**
   opening the popup and clicking **Capture current highlight**
4. In the popup, open **AI settings** and enter your OpenAI API key.
5. Choose a model and note style.
6. Click **Generate AI note** to turn your saved highlights into organized notes.
7. Review the result in the popup and use **Export for Word** if you want a downloadable document.

## PDF Support

- You can click **Import PDF** in the popup and choose a local PDF file.
- You can also combine imported PDFs with highlights captured from normal webpages.
- If no highlights were captured, the extension can generate structured notes from the imported PDF itself.

## Notes

- The extension stores data locally with `chrome.storage.local`.
- The export is a Word-friendly `.doc` file, not a true `.docx`.
- The default highlight shortcut is `Ctrl+Shift+H` on Windows/Linux and `Command+Shift+H` on macOS.
- You can change the shortcut at `chrome://extensions/shortcuts`.
- This extension uses the OpenAI API directly and requires the user to provide their own API key.

## Codex Disclosure

This extension was coded through Codex.
