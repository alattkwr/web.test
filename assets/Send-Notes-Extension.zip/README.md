# Highlight Notes Prototype

This is a Manifest V3 Chrome extension prototype for a no-backend workflow:

1. Highlight text on a webpage.
2. Save the selection into the extension.
3. Generate notes directly with the OpenAI API using the user's own key.
4. Keep the generated notes in the popup.
5. Export the running notes into a Word-friendly `.doc` file.

## Files

- `manifest.json`: Chrome extension manifest
- `background.js`: context menu setup and background storage handling
- `content.js`: reads the selected text and captures article text from the active webpage
- `popup.html`: popup UI
- `popup.css`: popup styling
- `popup.js`: popup behavior, local storage, prompt creation, import, export
- direct OpenAI API call: `fetch("https://api.openai.com/v1/responses", ...)`

## Quick test

1. Open `chrome://extensions`.
2. Turn on **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder:
   - `C:\Users\Admin\Downloads\codextst`
5. Pin the extension if you want easier access.

## MVP flow

1. Open any normal webpage.
2. Highlight a sentence or paragraph.
3. Either:
   - right-click and choose **Save Highlight to Notes**
   - or open the extension popup and click **Capture current highlight**
4. In the popup, open **AI settings**, add an OpenAI API key, choose a model, and click **Save**.
5. Click **Generate AI note**.
6. Review the generated note in the popup.
7. Click **Export for Word** to download a `.doc` file.

## PDF workflow

1. Open the popup.
2. Click **Import PDF** and choose a local PDF file.
3. Optionally capture supporting highlights from webpages as usual.
4. Click **Generate AI note**.

If no highlights were captured, the extension will generate structured notes for the imported PDF itself.

## Notes

- The export is a Word-friendly `.doc` HTML document, not a true `.docx` file.
- Everything is stored locally with `chrome.storage.local`.
- The prompt now includes both the highlighted text and a captured article snapshot so the notes keep more context.
- For PDFs opened in Chrome, the extension tries to use the underlying PDF file as model input instead of scraping the built-in PDF viewer.
- You can also import a local PDF directly from the popup, which avoids Chrome PDF viewer limitations entirely.
- The default shortcut is `Ctrl+Shift+H` on Windows/Linux and `Command+Shift+H` on macOS. You can change it at `chrome://extensions/shortcuts`.
- Chrome does not reliably allow an extension to replace the built-in `Ctrl+H` history shortcut.
- This prototype uses the OpenAI API directly and does not automate ChatGPT's website UI.
- Storing API keys in a browser extension is convenient for prototypes, but a backend is safer for production.
